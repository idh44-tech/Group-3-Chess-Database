let titlesArray = [];
let contentArray = [];
const prefix = 'task';

let taskCount=0;
let compCount=0;

function fillTitle()
{
    let currentCard = titlesArray.length;
    titlesArray.push(document.getElementById("newTitle").value);
    $(".test").append("Title:<p>" + titlesArray[currentCard] + "<p>");
}

function fillCard(currentCard)
{
    $("#" + prefix + currentCard).append("<h3 class=\"searchable\">" + titlesArray[currentCard] + "</h3>")
    $("#" + prefix + currentCard).append("<div class=\"searchable\">" + contentArray[currentCard] + "</div> <br></br>")
    $("#" + prefix + currentCard).append("<button id=\"task" + currentCard + "c\" type=\"button\" class=\"btn btn-success btn-sm\">Complete</button>")
    $("#" + prefix + currentCard).append("<button id=\"task" + currentCard + "d\" type=\"button\" class=\"btn btn-danger btn-sm\">Delete</button>")
    document.getElementById("task" + currentCard + "c").addEventListener("click", function(){markComplete(currentCard)});
    document.getElementById("task" + currentCard + "d").addEventListener("click", function(){
        deleteCard(currentCard)
    });
}

function makeNewCol(){
    let currentCard = contentArray.length;
    titlesArray.push(document.getElementById("newTitle").value);
    contentArray.push(document.getElementById("newContent").value);
    $(".row").append("<div id=\"task" + currentCard + "\" class=\"col-4 text-center text-wrap border border-primary\"> </div>");
    fillCard(currentCard);
    taskCount=taskCount+1;
    updtcount();
}

function markComplete(currentCard){
    $("#" + prefix + currentCard).replaceWith("<div id=\"task" + currentCard + "\" class=\"col-4 text-center text-wrap border border-success\">  </div>");
    fillCard(currentCard);
    compCount=compCount+1;
    updtcomp();
}

function deleteCard(currentCard)
{
    $("#" + prefix + currentCard).replaceWith("");
    taskCount=taskCount-1;
    updtcount();
}

function searchbar()
{
    let input = document.getElementById("searchbar").value;
    let currentWord = document.getElementsByClassName("searchable");

    for (i = 0; i < currentWord.length; i++)
    {
        currentWord[i].style.color = "black";
    }

    for (i = 0; i < currentWord.length; i++)
    {
        if (currentWord[i].innerHTML.includes(input)) 
        {
            currentWord[i].style.color = "green";
        }
    }
}

function updtcount(){
    let countsection = document.getElementById("counter");
    countsection.textContent=taskCount;
 }
 function updtcomp(){
    let compsec = document.getElementById("compcounter");
    compsec.textContent=compCount;
 }

document.getElementById("titleSubmit").addEventListener("click", makeNewCol);
document.getElementById("searchbutton").addEventListener("click", searchbar);
onload(updtcount(),updtcomp());
 